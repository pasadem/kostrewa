import prisma from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin';

async function handler(req, res, user) {
  if (req.method === 'GET') {
    const orders = await prisma.order.findMany({
      include: {
        user: true,
        items: { include: { product: true } },
      },
      orderBy: { createdAt: 'desc' },
    });
    return res.json(orders);
  }

  res.status(405).end();
}

export default requireAdmin(handler);
